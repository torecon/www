/* torecon – News / Financial Trends data & renderer */
const NEWS_DATA = [
  {
    id: 1,
    date: '2026-03-07',
    tag_de: 'Geldpolitik',
    tag_en: 'Monetary Policy',
    title_de: 'EZB senkt Leitzins auf 2,25 % – weiterer Schritt im März erwartet',
    title_en: 'ECB cuts key rate to 2.25% – another step expected in March',
    excerpt_de: 'Die Europäische Zentralbank hat ihren Einlagenzins auf 2,25 % gesenkt. Angesichts rückläufiger Inflation und schwacher Konjunktur in der Eurozone wird für März ein weiterer Schritt diskutiert.',
    excerpt_en: 'The European Central Bank has cut its deposit rate to 2.25%. With inflation declining and weak eurozone growth, another move is being discussed for March.',
  },
  {
    id: 2,
    date: '2026-03-06',
    tag_de: 'Genossenschaftsbanken',
    tag_en: 'Cooperative Banks',
    title_de: 'DZ Bank Gruppe: Rekordjahr 2025 – Genossenschaftssektor weiter stark',
    title_en: 'DZ Bank Group: Record year 2025 – cooperative sector remains strong',
    excerpt_de: 'Die DZ Bank hat für 2025 ein Rekordergebnis bekanntgegeben. Der genossenschaftliche Sektor profitiert von stabiler Kundenbasis und gesundem Kreditportfolio.',
    excerpt_en: 'DZ Bank has announced a record result for 2025. The cooperative sector benefits from a stable customer base and healthy loan portfolio.',
  },
  {
    id: 3,
    date: '2026-03-05',
    tag_de: 'Regulierung',
    tag_en: 'Regulation',
    title_de: 'Basel IV vollständig in Kraft: Erste Bilanzierungseffekte sichtbar',
    title_en: 'Basel IV fully in force: First balance sheet effects visible',
    excerpt_de: 'Seit Januar 2026 gelten alle Basel-IV-Vorschriften. Kreditinstitute melden erste spürbare Auswirkungen auf Eigenkapitalquoten und Kreditvergabespielräume.',
    excerpt_en: 'All Basel IV rules have applied since January 2026. Credit institutions report the first noticeable effects on capital ratios and lending capacity.',
  },
  {
    id: 4,
    date: '2026-03-04',
    tag_de: 'Digitalisierung',
    tag_en: 'Digitalisation',
    title_de: 'KI-gestütztes Kreditscoring: BaFin veröffentlicht Leitlinien',
    title_en: 'AI-based credit scoring: BaFin publishes guidelines',
    excerpt_de: 'Die BaFin hat erstmals verbindliche Leitlinien für den Einsatz von KI-Modellen im Kreditvergabeprozess veröffentlicht. Transparenz und Erklärbarkeit stehen im Fokus.',
    excerpt_en: 'BaFin has published binding guidelines for the use of AI models in the lending process for the first time. Transparency and explainability are the focus.',
  },
  {
    id: 5,
    date: '2026-03-03',
    tag_de: 'Digitaler Euro',
    tag_en: 'Digital Euro',
    title_de: 'Digitaler Euro: EZB startet Pilotprogramm mit ausgewählten Banken',
    title_en: 'Digital Euro: ECB launches pilot programme with selected banks',
    excerpt_de: 'Die EZB hat die erste Pilotphase des digitalen Euro gestartet. Zwölf europäische Kreditinstitute nehmen an dem Programm teil, darunter zwei deutsche Genossenschaftsbanken.',
    excerpt_en: 'The ECB has launched the first pilot phase of the digital euro. Twelve European credit institutions are participating, including two German cooperative banks.',
  },
  {
    id: 6,
    date: '2026-03-02',
    tag_de: 'Ukraine',
    tag_en: 'Ukraine',
    title_de: 'Ukraine-Wiederaufbau: EBRD verdoppelt Kreditlinie für Finanzsektor',
    title_en: 'Ukraine reconstruction: EBRD doubles credit line for financial sector',
    excerpt_de: 'Die Europäische Bank für Wiederaufbau und Entwicklung stellt weitere 5 Mrd. Euro für den ukrainischen Finanzsektor bereit. Europäische Banken sind als Durchleitinstitute gefragt.',
    excerpt_en: 'The EBRD is providing a further €5bn for the Ukrainian financial sector. European banks are in demand as intermediary institutions.',
  },
  {
    id: 7,
    date: '2026-02-28',
    tag_de: 'Zinsmarge',
    tag_en: 'Interest Margin',
    title_de: 'Sinkende Leitzinsen: Regionalbanken überdenken Einlagenstrategie',
    title_en: 'Falling key rates: Regional banks rethink deposit strategy',
    excerpt_de: 'Mit dem Rückgang der EZB-Zinsen gerät das Einlagengeschäft unter Druck. Viele Regionalbanken und Sparkassen passen ihre Konditionenmodelle neu an.',
    excerpt_en: 'With ECB rates falling, the deposit business is under pressure. Many regional banks and savings banks are adjusting their pricing models.',
  },
  {
    id: 8,
    date: '2026-02-27',
    tag_de: 'Nachhaltigkeit',
    tag_en: 'Sustainability',
    title_de: 'CSRD-Umsetzung: Kreditinstitute stehen vor operativer Bewährungsprobe',
    title_en: 'CSRD implementation: Credit institutions face operational test',
    excerpt_de: 'Die ersten verpflichtenden Nachhaltigkeitsberichte nach CSRD sind fällig. Viele Kreditinstitute kämpfen mit Datenlücken und fehlendem Fachpersonal.',
    excerpt_en: 'The first mandatory sustainability reports under CSRD are due. Many credit institutions are struggling with data gaps and a lack of specialist staff.',
  },
];

function formatNewsDate(dateStr, lang) {
  const d = new Date(dateStr);
  return d.toLocaleDateString(lang === 'de' ? 'de-DE' : 'en-GB', {
    day: '2-digit', month: 'long', year: 'numeric'
  });
}

function renderNews(containerId = 'news-container', limit = null) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const lang = currentLang || 'de';
  const items = limit ? NEWS_DATA.slice(0, limit) : NEWS_DATA;
  container.innerHTML = items.map(item => `
    <article class="news-card">
      <div class="news-card-top">
        <span class="news-tag">${lang === 'de' ? item.tag_de : item.tag_en}</span>
        <span class="news-date">${formatNewsDate(item.date, lang)}</span>
      </div>
      <div class="news-card-body">
        <h3>${lang === 'de' ? item.title_de : item.title_en}</h3>
        <p>${lang === 'de' ? item.excerpt_de : item.excerpt_en}</p>
      </div>
    </article>
  `).join('');
}
